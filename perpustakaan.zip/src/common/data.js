const programStudi = ['Teknik Informatika', 'Sistem Informasi', 'Teknologi Informasi']
const qr = [
    "jSE255XCzRShTFi7fCDEaZTpuzvYmUSE",
    "DqR0gnlvuTT4n9egaerpGJE9XNMr4JlJ",
    "RfhF1Llnu8x2241mhu7cJNQFw4x8jGb8",
    "qKHgGUBKN2mgzR4BWkVaakFtEKnH1dSV",
    "2lHZrlmLeJWD0CXFky9h3ZTNTanC49rN",
    "O4TKmiMnEeiHN49ydwdkU4sH9dLZv8O1",
    "hyt3hnXs81nE2riocJnSbBLJYx1n8NRe",
    "AHmO7uu3AIcXboGQ9m1nEwEPWunh7uTS",
    "j7L9eCrdgBxLnvRZogyCGWCF5zt2uSe7",
    "mFbFIz0Kuu5MA48Nnr5gacArm5vLbU7y",
    "C50ZWcttLnUMYqnE9Eide918zkayVtm7",
    "aaD22gfjDe66Er26cAryX7r6Z3gNFNjW",
    "MU2EoIUZ1xQnMdilGLQYgklxJ2jd2KQL",
    "AQJzD9QSiZqk05jYOC0JoEotnnIxbgAC",
    "rmNjVCfHuElkQtcJ8j8DIoLRrbQy4QqS",
    "uPof8C2ZGmqIynUz1CwIvrrAMzwOFxva",
    "AFG2sEildyhq15pKbhs6Lt6jegQTZ9q1",
    "v53p6ec7jQV2DxYgZn13udwqORl50mIT",
    "5urAoWCqFOl4VJP3zeg5iYy7IBpOHwqC",
];
module.exports = { programStudi, qr };